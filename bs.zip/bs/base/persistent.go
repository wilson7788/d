package base

import (
	"bs/conf"
	"encoding/json"
	"fmt"
	"github.com/name5566/leaf/log"
	"io/ioutil"
	"os"
	"path/filepath"
	"sync"
)

type IModel interface {
	PKName() string
	TableName() string
}

type IMergeModel interface {
	IModel
	Merge(data IMergeModel)
	NewMergeData() IMergeModel
}

var persistent *DataQueue
var persistentDirectory string

type DataQueue struct {
	queue []IModel
	mu    sync.Mutex
	cond  *sync.Cond
}

func SetupDataQueue() {
	pwd, err := os.Getwd()
	if err != nil {
		panic(err)
	}
	persistentDirectory = pwd + "/" + conf.Server.PersistentDir + "/"
	log.Debug("Persistent directory: %s", persistentDirectory)

	persistent = &DataQueue{
		queue: make([]IModel, 0),
	}
	persistent.cond = sync.NewCond(&persistent.mu)
	persistent.running()
}

func Commit(data IModel) error {
	if persistent == nil {
		return fmt.Errorf("data queue not running")
	}
	persistent.commit(data)
	return nil
}

func (dq *DataQueue) commit(data IModel) {
	dq.mu.Lock()
	defer dq.mu.Unlock()
	dq.queue = append(dq.queue, data)
	dq.cond.Signal()
}

func (dq *DataQueue) running() {
	log.Debug("data queue running.")
	go func() {
		for {
			dq.cond.L.Lock()
			if len(dq.queue) == 0 {
				dq.cond.Wait()
			}
			tmpQueue := dq.queue
			dq.queue = make([]IModel, 0)
			dq.cond.L.Unlock()
			for _, data := range tmpQueue {
				err := dq.SaveData(data)
				if err != nil {
					log.Error("data %s, pk = %s save err: %+v", data.TableName(), data.PKName(), err)
				} else {
					log.Debug("data %s, pk = %s save ok", data.TableName(), data.PKName())
				}
			}
		}
	}()
}

func (dq *DataQueue) SaveData(data IModel) error {
	var raw []byte
	var err error
	mergeAble, ok := data.(IMergeModel)
	if ok {
		mergeData := mergeAble.NewMergeData()
		err = LoadData(mergeData)
		if err == nil {
			mergeAble.Merge(mergeData)
		}
		raw, err = json.Marshal(mergeAble)
		if err != nil {
			return err
		}
	} else {
		raw, err = json.Marshal(data)
		if err != nil {
			return err
		}
	}
	fileName := persistentDirectory + "/" + data.TableName() + "/" + data.PKName() + ".json"
	// Get the directory path from the file path
	dirPath := filepath.Dir(fileName)
	// Create the directory if it doesn't exist
	err = os.MkdirAll(dirPath, 0755)
	if err != nil {
		return err
	}
	return ioutil.WriteFile(fileName, raw, 0644)
}

func LoadData(data IModel) error {
	fileName := persistentDirectory + "/" + data.TableName() + "/" + data.PKName() + ".json"
	// 判断文件是否存在
	if _, err := os.Stat(fileName); os.IsNotExist(err) {
		return fmt.Errorf("file %s not exist", fileName)
	}

	// 打开文件
	raw, err := ioutil.ReadFile(fileName)
	if err != nil {
		return err
	}

	return json.Unmarshal(raw, data)
}
