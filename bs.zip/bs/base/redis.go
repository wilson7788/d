package base

import (
	"encoding/json"
	"fmt"
	"github.com/go-redis/redis"
	"github.com/name5566/leaf/log"
)

var c *redis.Client
var prefix string

func SetupRedis(addr string, appName string) {
	c = redis.NewClient(&redis.Options{
		Addr: addr,
	})
	if c == nil {
		panic("redis connect fatal")
	}
	prefix = appName
	log.Debug("redis %s connect ok", addr)
}

func RedisHSet(data IModel) error {
	if c == nil {
		return fmt.Errorf("redis not connected")
	}
	if data.PKName() == "" {
		panic("redis model fatal")
	}
	raw, err := json.Marshal(data)
	if err != nil {
		return err
	}
	key := fmt.Sprintf("%s:%s", prefix, data.TableName())
	result := c.HSet(key, data.PKName(), raw)
	err = result.Err()
	if err != nil {
		log.Error("redis hset %s, field:%s fatal", key, data.PKName())
	}
	return err
}

func RedisHSetMerged(data IModel) error {
	if c == nil {
		return fmt.Errorf("redis not connected")
	}
	if data.PKName() == "" {
		panic("redis model fatal")
	}
	mergeAble, ok := data.(IMergeModel)
	if ok {
		left := mergeAble.NewMergeData()
		if err := RedisHGet(left); err == nil {
			mergeAble.Merge(left)
		}
	}
	raw, err := json.Marshal(mergeAble)
	if err != nil {
		return err
	}
	key := fmt.Sprintf("%s:%s", prefix, data.TableName())
	result := c.HSet(key, data.PKName(), raw)
	err = result.Err()
	if err != nil {
		log.Error("redis hset %s, field:%s fatal", key, data.PKName())
	}
	return err
}

func RedisHGet(data IModel) error {
	if c == nil {
		return fmt.Errorf("redis not connected")
	}
	key := fmt.Sprintf("%s:%s", prefix, data.TableName())
	result := c.HGet(key, data.PKName())
	if result.Err() != nil {
		return result.Err()
	}
	raw, err := result.Bytes()
	if err != nil {
		return err
	}
	return json.Unmarshal(raw, data)
}

func RedisIncScore(k string, score float64, member string) error {
	if c == nil {
		return fmt.Errorf("redis not connected")
	}
	key := fmt.Sprintf("%s:%s", prefix, k)
	result := c.ZIncr(key, redis.Z{
		Score:  score,
		Member: member,
	})
	return result.Err()
}

func RedisMemberScore(k string, member string) (float64, error) {
	if c == nil {
		return 0, fmt.Errorf("redis not connnected")
	}
	key := fmt.Sprintf("%s:%s", prefix, k)
	return c.ZScore(key, member).Result()
}

func RedisMemberRevRank(k string, member string) (int64, error) {
	if c == nil {
		return 0, fmt.Errorf("redis not connnected")
	}
	key := fmt.Sprintf("%s:%s", prefix, k)
	return c.ZRevRank(key, member).Result()
}

func RedisZRevRange(k string, start, end int64) ([]redis.Z, error) {
	if c == nil {
		return nil, fmt.Errorf("redis not connnected")
	}
	key := fmt.Sprintf("%s:%s", prefix, k)
	return c.ZRevRangeWithScores(key, start, end).Result()
}

func RedisListPush(k string, data interface{}) error {
	if c == nil {
		return fmt.Errorf("redis not connnected")
	}
	key := fmt.Sprintf("%s:%s", prefix, k)
	raw, err := json.Marshal(data)
	if err != nil {
		return err
	}
	return c.RPush(key, raw).Err()
}

func RedisListLen(k string) (int64, error) {
	if c == nil {
		return 0, fmt.Errorf("redis not connnected")
	}
	key := fmt.Sprintf("%s:%s", prefix, k)
	return c.LLen(key).Result()
}

func RedisListRange(k string, start, end int64) ([]string, error) {
	if c == nil {
		return nil, fmt.Errorf("redis not connnected")
	}
	key := fmt.Sprintf("%s:%s", prefix, k)
	return c.LRange(key, start, end).Result()
}

func RedisDelKey(k string) error {
	if c == nil {
		return fmt.Errorf("redis not connnected")
	}
	key := fmt.Sprintf("%s:%s", prefix, k)
	return c.Del(key).Err()
}
