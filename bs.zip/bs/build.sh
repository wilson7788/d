#!/bin/bash

# 检查参数数量
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <target_platform>"
    echo "Where <target_platform> is either 'linux' or 'mac'."
    exit 1
fi

# 定义目标平台变量
TARGET_PLATFORM=$1
TARGET_LINUX_NAME="bs.linux"
TARGET_MAC_NAME="bs.mac"
# 根据目标平台设置GOOS和GOARCH环境变量
case $TARGET_PLATFORM in
    linux)
        CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build -o $TARGET_LINUX_NAME
        BIN_NAME=$TARGET_LINUX_NAME
        ;;
    mac)
        GOOS=darwin go build -o $TARGET_MAC_NAME
        BIN_NAME=$TARGET_MAC_NAME
        ;;
    *)
        echo "Invalid target platform: $TARGET_PLATFORM"
        exit 1
        ;;
esac

# 检查编译是否成功
if [ $? -eq 0 ]; then
    echo "Go program $BIN_NAME compiled successfully for $TARGET_PLATFORM."
else
    echo "Failed to compile Go program $BIN_NAME for $TARGET_PLATFORM."
    exit 1
fi