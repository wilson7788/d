package conf

import (
	"encoding/json"
	"github.com/name5566/leaf/log"
	"io/ioutil"
)

var Server struct {
	LogLevel          string
	LogPath           string
	WSAddr            string
	CertFile          string
	KeyFile           string
	TCPAddr           string
	WEBAddr           string
	ServiceNetwork    string
	ServiceAddress    string
	MaxConnNum        int
	ConsolePort       int
	ProfilePath       string
	OpenRobot         bool
	RobotNum          int32
	PlatformDriveMode bool
	MainSiteAddr      string
	GameId            uint64
	PersistentDir     string
	RedisAddr         string
}

func init() {
	data, err := ioutil.ReadFile("conf/server.json")
	if err != nil {
		log.Fatal("%v", err)
	}
	err = json.Unmarshal(data, &Server)
	if err != nil {
		log.Fatal("%v", err)
	}
}
