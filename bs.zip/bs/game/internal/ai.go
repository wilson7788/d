package internal

import (
	"bs/conf"
	"fmt"
	"github.com/name5566/leaf/module"
	"github.com/name5566/leaf/timer"
	"math/rand"
	"time"
)

type Ai struct {
	robotNum int64
	robots   map[string]*User
	skeleton *module.Skeleton
	t        *timer.Timer
}

var dycAi *Ai

func SetupAi(skeleton *module.Skeleton) {
	if conf.Server.OpenRobot == false {
		return
	}
	dycAi = &Ai{
		robotNum: 0,
		skeleton: skeleton,
		robots:   make(map[string]*User),
	}
	dycAi.t = dycAi.skeleton.AfterFunc(time.Second*3, dycAi.run)
}

func (ai *Ai) run() {

	ai.checkUsers()

	ai.checkMove()

	ai.skeleton.AfterFunc(3*time.Second, ai.run)
}

func (ai *Ai) checkUsers() {
	if ai.robotNum >= int64(conf.Server.RobotNum) {
		return
	}

	userId := fmt.Sprintf("0xd%08d8xd*%04d", ai.robotNum, ai.robotNum)
	u := UserMgr.NewUser(nil, userId)

	Logic.Enter(userId)

	ai.robots[userId] = u

	ai.robotNum++
}

func (ai *Ai) checkMove() {
	if ai.robotNum == 0 {
		return
	}

	moveNum := ai.robotNum / 2
	for userId, _ := range ai.robots {
		to := rand.Int31n(RoomNum-1) + 1
		Logic.Move(userId, to)
		moveNum--
		if moveNum <= 0 {
			break
		}
	}
}
