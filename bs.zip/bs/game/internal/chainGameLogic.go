package internal

import (
	"bs/base"
	"bs/conf"
	"bs/msg"
	"bs/msg/pb_bs"
	"context"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/name5566/leaf/log"
	"github.com/name5566/leaf/module"
	"google.golang.org/grpc"
)

type ChainGameLogic struct {
	BaseLogic
	conn           *grpc.ClientConn
	chainBlockAddr string
	chainId        string
}

func (pl *ChainGameLogic) InitLogic(s *module.Skeleton, gameId uint64) error {
	pl.Init(s, gameId)

	conn, err := grpc.Dial(conf.Server.MainSiteAddr, grpc.WithInsecure())
	if err != nil {
		log.Fatal("main site connect fatal, err: %+v", err)
	}
	log.Debug("main site rpc connect ok, remote: %+v", conn.Target())
	pl.conn = conn

	// 请求主站数据
	rpcGameState := pb_bs.NewGameStateClient(pl.conn)
	rsp, err := rpcGameState.GetGameState(context.Background(), &pb_bs.GetGameStateRequest{
		GameId: pl.gameId,
	})
	log.Debug("rpc GetGameState rsp:%+v", rsp.String())
	if err != nil {
		log.Fatal("rpc GetGameState fatal: %+v", err)
	}
	pl.roundNo = int64(rsp.RoundNo)
	state, ok := GameStateMapping[rsp.RoundState]
	if !ok {
		log.Fatal("round state:%s err, not match in game", rsp.RoundState)
	}
	pl.state = state
	pl.stateStartTime = time.Unix(rsp.StateStartTime, 0)

	rpcGameConfig := pb_bs.NewGameConfigClient(pl.conn)
	configRsp, err := rpcGameConfig.GetGameConfig(context.Background(), &pb_bs.GetGameConfigRequest{
		GameId: pl.gameId,
	})
	if err != nil {
		panic(err)
	}
	log.Debug("rpc GetGameConfig rsp:%+v", configRsp.String())
	if len(configRsp.Amounts) > 0 {
		for _, amt := range configRsp.Amounts {
			f, _ := strconv.ParseFloat(amt, 64)
			pl.betNumList = append(pl.betNumList, f)
		}
	}
	pl.roundMaxPlayers = configRsp.MaxPlayers
	pl.chainBlockAddr = configRsp.ChainAddress
	pl.countDownSecond = int32(configRsp.CountDownEndTime)
	pl.chainId = fmt.Sprint(configRsp.ChainId)
	pl.poolAmt = configRsp.PoolAmt

	tmpRecords := make([]*RoundRecord, 0)
	recordRsp, err := pb_bs.NewUserGameRecordClient(pl.conn).GetLastGameSettleRecord(context.Background(), &pb_bs.GetLastGameSettleResultsRequest{
		GameId: fmt.Sprint(pl.gameId),
	})
	if err != nil {
		log.Error("rpc GetLastGameSettleRecord err=%+v", err)
	} else {
		log.Debug("rpc GetLastGameSettleRecord rsp:%+v", recordRsp)
		pl.atkRoomIdStats = make(map[int32]int32)
		for _, r := range recordRsp.RoundRecords {
			atkRoomIds := GetRoomIdsByString(r.RoomId)
			for _, rid := range atkRoomIds {
				pl.atkRoomIdStats[rid]++
			}
			record := &RoundRecord{
				RoundNo:  int64(r.RoundNo),
				AtkRooms: atkRoomIds,
			}
			tmpRecords = append(tmpRecords, record)
			base.RedisHSet(record)
		}
		for i := len(tmpRecords) - 1; i > 0; i-- {
			pl.records = append(pl.records, tmpRecords[i])
		}
	}

	gameData := &GameData{GameId: pl.gameId}
	if err = base.RedisHGet(gameData); err == nil && gameData.RoundNo == pl.roundNo {
		if len(gameData.UserPos) > 0 {
			pl.userPos = gameData.UserPos
		}
		if len(gameData.UserBets) > 0 {
			pl.userBets = gameData.UserBets
		}
		if len(gameData.RoomBets) > 0 {
			pl.roomBets = gameData.RoomBets
		}
		pl.roundStartTime = time.Unix(gameData.RoundStartTime, 0)
	}
	log.Debug("game state sync ok, round: %d, current state: %s-%d", pl.roundNo, rsp.RoundState, pl.state)
	return nil
}

func (pl *ChainGameLogic) StartResulting(atkSteps []int32, data interface{}) {
	pl.BaseLogic.StartResulting(atkSteps, data)

	userResults := make(map[string]*pb_bs.UserResult)
	resultData, ok := data.(*pb_bs.SyncRoundResultReq)
	if !ok {
		log.Error("data type not SyncRoundResultReq")
	} else if len(atkSteps) > 0 {
		// 同步结果给所有玩家
		for _, r := range resultData.UserResults {
			userResults[r.Uid] = r

			ntf := &msg.ResultNtf{
				UserId:   r.Uid,
				State:    pl.state,
				AtkRooms: atkSteps,
			}
			score, _ := strconv.ParseFloat(r.IncomePoints, 64)
			winCoins, _ := strconv.ParseFloat(r.WinningsAmount, 64)
			tradeAmt, _ := strconv.ParseFloat(r.TradeAmount, 64)

			ntf.GetPoints = score
			ntf.WinAmt = winCoins
			if r.BetResult == "win" {
				ntf.ResultStatus = msg.ResultStatusSuccess
			} else if r.BetResult == "lose" {
				ntf.ResultStatus = msg.ResultStatusFail
				ntf.WinAmt = tradeAmt
			} else {
				ntf.ResultStatus = msg.ResultStatusNotJoin
			}

			base.RedisHSetMerged(&UserBetData{
				UserId:        r.Uid,
				RoundNo:       pl.roundNo,
				WinAmt:        ntf.WinAmt,
				GetScore:      ntf.GetPoints,
				AtkRooms:      atkSteps,
				Status:        msg.TradeStatusDone,
				BetTime:       time.Now().Unix(),
				SettleHash:    r.SettleHash,
				LockBlockHash: r.LockBlockHash,
				LockHash:      r.LockTxHash,
				LockTime:      int64(r.LockTime),
				RandomGenTime: int64(r.GenerateRandomValueTime),
				AdminAddress:  r.AdminAddress,
			})

			// 排行统计
			betAmt, _ := strconv.ParseFloat(r.TradeAmount, 64)
			base.RedisIncScore(TodayRankKey(), betAmt, r.Uid)
			UserMgr.SendMsg(r.Uid, ntf)
		}
	}
	for userId := range pl.userPos {
		_, ok := userResults[userId]
		if !ok {
			UserMgr.SendMsg(userId, &msg.ResultNtf{
				UserId:       userId,
				State:        pl.state,
				AtkRooms:     atkSteps,
				GetPoints:    0,
				WinAmt:       0,
				ResultStatus: msg.ResultStatusNotJoin,
			})
		}
	}
}

func (pl *ChainGameLogic) Bets(userId string, betCoins float64, txHash string) (err error) {

	defer func() {
		if err != nil {
			UserMgr.SendMsg(userId, &msg.BetRsp{ErrCode: msg.ErrCodeInvalidAuth})
		}
	}()

	ur := UserMgr.GetUser(userId)
	if ur == nil {
		log.Error("user %s not in game", userId)
		return fmt.Errorf("user %s not in game", userId)
	}

	roomId, ok := pl.userPos[userId]
	if !ok {
		UserMgr.SendMsg(userId, &msg.BetRsp{ErrCode: msg.ErrCodeNotInRoom, ErrMsg: "user not select a cell"})
		return nil
	}

	req := &pb_bs.SaveGameRecordRequest{
		GameId:             pl.gameId,
		RoundNumber:        uint64(pl.roundNo),
		UserId:             userId,
		UserSelectLocation: uint32(roomId),
		Location:           uint32(roomId),
		BetAmount:          fmt.Sprint(betCoins),
		BetHash:            txHash,
	}
	log.Debug("rpc SaveGameRecord req: %+v", req)
	rsp, err := pb_bs.NewGameRecordClient(pl.conn).SaveGameRecord(context.Background(), req)
	if err != nil {
		log.Error("rpc SaveGameRecord err: %+v", err)
		return err
	}
	log.Debug("rpc SaveGameRecord rsp: %+v", rsp)
	if rsp.Code != 200 {
		log.Error("rcp SaveGameRecord not ok, errCode=%d", rsp.Code)
		return fmt.Errorf("rcp SaveGameRecord not ok, errCode=%d, msg=%s", rsp.Code, rsp.Error)
	}
	return pl.BaseLogic.Bets(userId, betCoins, txHash)
}

func (pl *ChainGameLogic) Enter(userId string) (err error) {

	defer func() {
		if err != nil {
			UserMgr.SendMsg(userId, &msg.EnterGameRsp{
				ErrCode: msg.ErrCodeInvalidAuth,
			})
		}
	}()

	u := UserMgr.GetUser(userId)
	if u == nil {
		return nil
	}
	if u.IsNoneAgent() {
		return pl.BaseLogic.EnterGame(userId, pl)
	}
	req := &pb_bs.UserRegisterRequest{Address: userId}
	log.Debug("rpc Register req: %+v", req)
	rsp, err := pb_bs.NewRegisterUserClient(pl.conn).Register(context.Background(), req)
	if err != nil {
		log.Error("rpc Register err: %+v", err)
		return err
	}
	log.Debug("rpc Register rsp: %+v", rsp)
	if rsp.Code != 200 {
		log.Error("rcp Register not ok, errCode=%d", rsp.Code)
		return fmt.Errorf("rcp Register not ok, errCode=%d, msg=%s", rsp.Code, rsp.Error)
	}

	loginReq := &pb_bs.GetLoginUserRequest{Token: rsp.Token}
	log.Debug("rpc GetLoginUserRequest req %+v", loginReq)
	loginRsp, err := pb_bs.NewLoginUserClient(pl.conn).GetLoginUser(context.Background(), loginReq)
	if err != nil {
		log.Error("rpc GetLoginUser err: %+v", err)
		return err
	}
	if loginRsp.Code != 200 {
		log.Error("rpc GetLoginUser err code=%d, err=%s", loginRsp.Code, loginRsp.Error)
		return fmt.Errorf("rpc GetLoginUser errcode=%d, err=%s", loginRsp.Code, loginRsp.Error)
	}
	userInfo := &UserInfo{
		UserId:   userId,
		SkinId:   int32(loginRsp.Skinid),
		NickName: loginRsp.Nickname,
	}
	err = base.RedisHSet(userInfo)
	if err != nil {
		return err
	}
	u.SkinId = userInfo.SkinId
	u.NickName = userInfo.NickName
	return pl.BaseLogic.EnterGame(userId, pl)
}

func (pl *ChainGameLogic) GetGameData() *msg.GameData {
	data := pl.BaseLogic.GetGameData()
	data.ChainBlockAddress = pl.chainBlockAddr
	data.ChainId = pl.chainId
	return data
}

func (pl *ChainGameLogic) GetRecords(userId string) {
	rsp := &msg.GetRecordRsp{
		GameRoundRecords: make([]msg.GameRoundRecord, 0),
		UserRoundRecords: make([]msg.UserRoundRecord, 0),
		AtkRoomIdStats:   make([]msg.AtkRoomStats, 0),
	}

	for rid, num := range pl.atkRoomIdStats {
		rsp.AtkRoomIdStats = append(rsp.AtkRoomIdStats, msg.AtkRoomStats{
			RoomId: rid,
			AtkNum: num,
		})
	}

	for i, l := pl.roundNo, 0; i > 0 && l < 10; i-- {
		record := &RoundRecord{RoundNo: i}
		if er := base.RedisHGet(record); er != nil {
			continue
		}
		if !CheckRoomIds(record.AtkRooms) {
			continue
		}
		l++
		rsp.GameRoundRecords = append(rsp.GameRoundRecords, msg.GameRoundRecord{RoundNo: record.RoundNo, AtkRooms: record.AtkRooms})
	}

	for i, l := pl.roundNo, 0; i > 0 && l < 20; i-- {
		record := &UserBetData{UserId: userId, RoundNo: i}
		if er := base.RedisHGet(record); er != nil {
			continue
		}
		if !CheckRoomIds(record.AtkRooms) {
			continue
		}
		l++
		isWin := false
		for _, rid := range record.AtkRooms {
			if rid == record.BetRoomId {
				isWin = true
				break
			}
		}
		rsp.UserRoundRecords = append(rsp.UserRoundRecords, msg.UserRoundRecord{
			UserId:        userId,
			RoundNo:       record.RoundNo,
			StayRoomId:    record.BetRoomId,
			AtkRooms:      record.AtkRooms,
			BetAmt:        record.BetAmt,
			WinAmt:        record.WinAmt,
			Points:        record.GetScore,
			RoundTime:     record.BetTime * 1000,
			IsWin:         isWin,
			SettleHash:    record.SettleHash,
			LockBlockHash: record.LockBlockHash,
			LockHash:      record.LockHash,
			LockTime:      record.LockTime,
			RandomGenTime: record.RandomGenTime,
			AdminAddress:  record.AdminAddress,
		})
	}

	// 如果游戏端记录数据不存在，向主站同步一次
	if len(rsp.UserRoundRecords) == 0 {
		recordRsp, err := pb_bs.NewUserGameRecordClient(pl.conn).GetUserGameRecord(context.Background(), &pb_bs.GetUserRecordsRequest{
			GameId:    pl.gameId,
			UserId:    userId,
			Pageindex: 1,
			Pagecount: 30,
		})
		if err != nil {
			log.Error("rpc GetUserGameRecord err=%+v", err)
		} else {
			if recordRsp.Code != 200 {
				log.Error("rpc GetUserGameRecord err code=%d, err=%s", recordRsp.Code, recordRsp.Error)
			} else {
				for _, r := range recordRsp.Records {
					putAmt, _ := strconv.ParseFloat(r.PutAmt, 64)
					winAmt, _ := strconv.ParseFloat(r.WinAmt, 64)
					getScore, _ := strconv.ParseFloat(r.GetScore, 64)

					atkRoomIds := GetRoomIdsByString(r.AtkRoomId)

					record := &UserBetData{
						UserId:        r.UserId,
						RoundNo:       int64(r.RoundNo),
						BetRoomId:     r.SelectRoomId,
						BetAmt:        putAmt,
						TxHash:        r.BetHash,
						BetTime:       r.BetTime / 1000,
						Status:        msg.TradeStatusDone,
						AtkRooms:      atkRoomIds,
						WinAmt:        winAmt,
						GetScore:      getScore,
						TradeResult:   msg.TradeResultOk,
						LockHash:      r.LockTxHash,
						LockBlockHash: r.LockBlockHash,
						LockTime:      int64(r.LockTime),
						RandomGenTime: int64(r.GenerateRandomValueTime),
						AdminAddress:  r.AdminAddress,
						SettleHash:    r.SettleHash,
					}
					base.RedisHSetMerged(record)

					isWin := false
					for _, rid := range record.AtkRooms {
						if rid == record.BetRoomId {
							isWin = true
							break
						}
					}

					if !CheckRoomIds(record.AtkRooms) {
						continue
					}

					rsp.UserRoundRecords = append(rsp.UserRoundRecords, msg.UserRoundRecord{
						UserId:        userId,
						RoundNo:       record.RoundNo,
						StayRoomId:    record.BetRoomId,
						AtkRooms:      record.AtkRooms,
						BetAmt:        record.BetAmt,
						WinAmt:        record.WinAmt,
						Points:        record.GetScore,
						RoundTime:     record.BetTime * 1000,
						IsWin:         isWin,
						SettleHash:    record.SettleHash,
						LockBlockHash: record.LockBlockHash,
						LockHash:      record.LockHash,
						LockTime:      record.LockTime,
						RandomGenTime: record.RandomGenTime,
						AdminAddress:  record.AdminAddress,
					})
				}
				log.Debug("rpc GetUserGameRecord ok, userid=%s", userId)
			}
		}
	}

	UserMgr.SendMsg(userId, rsp)
}

func (pl *ChainGameLogic) GetRanks(userId string, rankType int32) {
	rsp := &msg.GetRankRsp{
		Top3Ranks:  make([]msg.RankItem, 0),
		RankType:   rankType,
		Ranks:      make([]msg.RankItem, 0),
		SelfRankNo: 0,
		SelfWinAmt: "",
		SelfPutAmt: "",
	}

	// 检查是否游戏有昨日榜单数据，没有的话同步一下
	needSync := false
	yesterdayRankTime := NewKvModel(YesterdayRankSyncTime, YesterdayRankKey())
	if err := base.RedisHGet(yesterdayRankTime); err != nil || yesterdayRankTime.V == "" {
		needSync = true
	}
	yesterdayRankLen, err := base.RedisListLen(YesterdayRankKey())
	if err != nil || yesterdayRankLen == 0 || needSync {
		req := &pb_bs.GetGameRankRequest{GameId: pl.gameId, UserId: userId, Pageindex: 1, Pagecount: 50}
		rankRsp, err := pb_bs.NewGameRankClient(pl.conn).GetGameYesterdayRank(context.Background(), req)
		if err != nil {
			log.Error("rsp GetGameYesterdayRank err: %+v", err)
		} else {
			base.RedisDelKey(YesterdayRankKey())

			pl.poolAmt = rankRsp.TotalPoolAmount
			for _, r := range rankRsp.YesterdayRankData {
				name := r.Nickname
				if len(name) == 0 && len(r.UserId) > 8 {
					name = r.UserId[:4] + "**" + name[len(r.UserId)-4:]
				}
				rankItem := &msg.RankItem{
					UserId:  r.UserId,
					SortNo:  int32(r.SortOrder),
					Name:    name,
					SkinId:  int32(r.Skinid),
					PutInto: r.Putamt,
					WinAmt:  r.Winamt,
				}
				base.RedisListPush(YesterdayRankKey(), rankItem)
			}

			if rankRsp.RewardStatus {
				yesterdayRankTime.V = fmt.Sprint(time.Now().Unix())
				base.RedisHSet(yesterdayRankTime)
			}

			log.Debug("rpc GetGameYesterdayRank ok, rsp: %+v", rankRsp)
		}
	}

	top3, err := base.RedisListRange(YesterdayRankKey(), 0, 2)
	if err == nil {
		for _, r := range top3 {
			rankItem := &msg.RankItem{}
			er := json.Unmarshal([]byte(r), rankItem)
			if er != nil {
				continue
			}
			rsp.Top3Ranks = append(rsp.Top3Ranks, *rankItem)
		}
	}

	if rankType == 0 {
		myRank, _ := base.RedisMemberRevRank(TodayRankKey(), userId)
		myScore, _ := base.RedisMemberScore(TodayRankKey(), userId)
		if myScore > 0 {
			rsp.SelfRankNo = int32(myRank + 1)
			rsp.SelfPutAmt = fmt.Sprint(myScore)
		}

		if ranks, er := base.RedisZRevRange(TodayRankKey(), 0, 49); er == nil {
			for i, rank := range ranks {
				userInfo := UserMgr.GetUserInfo(rank.Member.(string))
				if userInfo == nil {
					continue
				}
				rsp.Ranks = append(rsp.Ranks, msg.RankItem{
					SortNo:  int32(i + 1),
					Name:    userInfo.GetName(),
					SkinId:  userInfo.SkinId,
					PutInto: fmt.Sprint(rank.Score),
					WinAmt:  "",
				})
			}
		}
	} else {
		lastRanks, er2 := base.RedisListRange(YesterdayRankKey(), 0, 49)
		if er2 == nil {
			var myRank *msg.RankItem
			for _, r := range lastRanks {
				rankItem := &msg.RankItem{}
				er := json.Unmarshal([]byte(r), rankItem)
				if er != nil {
					continue
				}
				rsp.Ranks = append(rsp.Ranks, *rankItem)
				if userId == rankItem.UserId {
					myRank = rankItem
				}
			}
			if myRank != nil {
				rsp.SelfRankNo = myRank.SortNo
				rsp.SelfWinAmt = myRank.WinAmt
				rsp.SelfPutAmt = myRank.PutInto
			}
		}
	}

	rsp.PoolAmt = pl.poolAmt
	UserMgr.SendMsg(userId, rsp)
}

func (pl *ChainGameLogic) SyncConfig(data *pb_bs.SyncConfigReq) error {
	if data.ChainAddress != "" {
		pl.chainBlockAddr = data.ChainAddress
	}
	if data.ChainId != "" {
		pl.chainId = data.ChainId
	}
	if data.PoolAmt != "" {
		pl.poolAmt = data.PoolAmt
	}
	return nil
}
