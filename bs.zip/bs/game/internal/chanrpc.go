package internal

import (
	"github.com/name5566/leaf/gate"
	"github.com/name5566/leaf/log"
)

func init() {
	skeleton.RegisterChanRPC("NewAgent", rpcNewAgent)
	skeleton.RegisterChanRPC("CloseAgent", rpcCloseAgent)
}

func rpcNewAgent(args []interface{}) {
	a := args[0].(gate.Agent)
	_ = a
	log.Debug("new agent: %s", a.RemoteAddr().String())
}

func rpcCloseAgent(args []interface{}) {
	a := args[0].(gate.Agent)
	UserMgr.DelAgent(a)
	log.Debug("close agent: %s", a.RemoteAddr().String())
	if a.UserData() == nil {
		return
	}
	uid := a.UserData().(string)
	Logic.Leave(uid)
}
