package internal

import (
	"bs/msg"
	"crypto/md5"
	"encoding/hex"
	"github.com/name5566/leaf/gate"
	"github.com/name5566/leaf/log"
	"reflect"
	"strings"
	"time"
)

func handleMsg(m interface{}, h interface{}) {
	skeleton.RegisterChanRPC(reflect.TypeOf(m), h)
}

func init() {
	handleMsg(&msg.EnterGameReq{}, handleEnter)
	handleMsg(&msg.MoveReq{}, handleMove)
	handleMsg(&msg.BetReq{}, handleBets)
	handleMsg(&msg.GetRecordReq{}, handleRecords)
	handleMsg(&msg.HeartBeat{}, handleHeartBeat)
	handleMsg(&msg.GetRankReq{}, handleRank)
}

func handleHeartBeat(args []interface{}) {
	_ = args[0].(*msg.HeartBeat)
	agt := args[1].(gate.Agent)
	userId, ok := agt.UserData().(string)
	if !ok {
		log.Error("agent:%s not login", agt.RemoteAddr())
		return
	}
	ur := UserMgr.GetUser(userId)
	if ur == nil {
		log.Error("user:%s not exist", userId)
		return
	}
	ur.LastTime = time.Now()
}

func handleEnter(args []interface{}) {
	req := args[0].(*msg.EnterGameReq)
	agt := args[1].(gate.Agent)

	if req.Token == "" {
		md5Sum := md5.Sum([]byte(agt.RemoteAddr().String()))
		userId := hex.EncodeToString(md5Sum[:])
		nickName := userId
		if len(userId) > 4 {
			nickName = userId[len(userId)-4:]
		}
		gameData := Logic.GetGameData()
		gameData.UserList = append(gameData.UserList, msg.UserInfo{
			UserId:   userId,
			NickName: nickName,
			SkinId:   1,
			RoomId:   -1,
		})
		rsp := &msg.EnterGameRsp{
			ErrCode:  0,
			GameData: *gameData,
			MyInfo: msg.SelfUserInfo{
				UserId:   userId,
				NickName: nickName,
				SkinId:   1,
				Points:   0,
				Coins:    0,
				Token:    "",
				BetData:  msg.BetData{},
				RoomId:   -1,
			},
		}
		agt.WriteMsg(rsp)
		log.Debug("guest enter, remote: %s, rsp: %+v", agt.RemoteAddr().String(), rsp)
	} else {
		userId := strings.ToLower(req.Token)
		newUser := UserMgr.NewUser(agt, userId)
		agt.SetUserData(newUser.Uid)
		Logic.Enter(newUser.Uid)
	}

	UserMgr.AddAgent(agt)
}

func handleMove(args []interface{}) {
	req := args[0].(*msg.MoveReq)
	agt := args[1].(gate.Agent)
	u := UserMgr.GetUser(req.UserId)
	if u == nil {
		agt.WriteMsg(&msg.MoveRsp{
			ErrCode: msg.ErrCodeInvalidAuth,
			Msg:     "user not enter",
		})
		log.Error("user: %s not found", req.UserId)
		return
	}
	if !u.IsAuth() {
		agt.WriteMsg(&msg.MoveRsp{
			ErrCode: msg.ErrCodeInvalidAuth,
			Msg:     "user not authed with token",
		})
		log.Error("user: %s not connected wallet, forbidden operation", req.UserId)
		return
	}
	Logic.Move(req.UserId, req.To)
}

func handleBets(args []interface{}) {
	req := args[0].(*msg.BetReq)
	agt := args[1].(gate.Agent)
	u := UserMgr.GetUser(req.UserId)
	if u == nil {
		agt.WriteMsg(&msg.BetRsp{
			ErrCode: msg.ErrCodeInvalidAuth,
		})
		log.Error("user: %s not found", req.UserId)
		return
	}
	if !u.IsAuth() {
		agt.WriteMsg(&msg.BetRsp{
			ErrCode: msg.ErrCodeInvalidAuth,
		})
		log.Error("user: %s not connected wallet, forbidden operation", req.UserId)
		return
	}
	Logic.Bets(req.UserId, req.BetAmt, req.TradeHash)
}

func handleRecords(args []interface{}) {
	req := args[0].(*msg.GetRecordReq)
	agt := args[1].(gate.Agent)
	u := UserMgr.GetUser(req.UserId)
	if u == nil {
		agt.WriteMsg(&msg.GetRecordRsp{})
		log.Error("user: %s not found", req.UserId)
		return
	}
	if !u.IsAuth() {
		agt.WriteMsg(&msg.GetRecordRsp{})
		log.Error("user: %s not connected wallet, forbidden operation", req.UserId)
		return
	}
	Logic.GetRecords(req.UserId)
}

func handleRank(args []interface{}) {
	req := args[0].(*msg.GetRankReq)
	agt := args[1].(gate.Agent)
	u := UserMgr.GetUser(req.UserId)
	if u == nil {
		agt.WriteMsg(&msg.GetRecordRsp{})
		log.Error("user: %s not found", req.UserId)
		return
	}
	if !u.IsAuth() {
		agt.WriteMsg(&msg.GetRecordRsp{})
		log.Error("user: %s not connected wallet, forbidden operation", req.UserId)
		return
	}
	Logic.GetRanks(req.UserId, req.RankType)
}
