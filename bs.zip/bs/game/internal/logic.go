package internal

import (
	"bs/base"
	"bs/conf"
	"bs/msg"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/name5566/leaf/log"
	"github.com/name5566/leaf/module"
)

const (
	RoomNum       = 4
	IdleTime      = 5 * time.Millisecond
	BetsTime      = 20 * time.Second
	CountDownTime = 30 * time.Second
	SettleTime    = 10 * time.Second
	ResultTime    = 30 * time.Second
)

const (
	StateIdle      = 0
	StateBets      = 1
	StateCountDown = 2
	StateSettle    = 3
	StateResult    = 4
)

// GameStateMapping 游戏状态 pause-暂停 start-游戏开始  countDown-人数够了 lock-锁定  settle-结算  terminate-终止
var GameStateMapping = map[string]int32{
	"pause":     StateIdle,
	"start":     StateBets,
	"countDown": StateCountDown,
	"lock":      StateSettle,
	"settle":    StateSettle,
	"terminate": StateResult,
}

var Logic ILogic

func SetLogic(s *module.Skeleton) {
	if conf.Server.PlatformDriveMode {
		Logic = &ChainGameLogic{}
	} else {
		Logic = &NormalLogic{}
	}
	Logic.InitLogic(s, conf.Server.GameId)
}

type ILogic interface {
	InitLogic(s *module.Skeleton, gameId uint64) error
	StartRound(roundNo int64)
	StartCountDown()
	StartSettle()
	StartResulting(atkSteps []int32, data interface{})
	SyncBetResult(userId string, txHash string, betAmt float64, roundNo int64, roomId int32)
	SyncBetFail(userId string, txHash string, roundNo int64)
	GetGameData() *msg.GameData
	Enter(userId string) error
	Leave(userId string)
	Move(userId string, to int32)
	Bets(userId string, betCoins float64, txHash string) error
	GetRecords(userId string)
	GetRanks(userId string, rankType int32)
}

const (
	YesterdayRankSyncTime = "yesterday_sync_time"
)

type BaseLogic struct {
	gameId          uint64
	roundNo         int64
	state           int32
	stateEndTime    time.Time
	stateStartTime  time.Time
	countDownSecond int32
	atkRooms        []int32
	userPos         map[string]int32
	roomBets        map[int32]float64
	userBets        map[string]float64
	skeleton        *module.Skeleton
	atkRoomIdStats  map[int32]int32
	roundStartTime  time.Time
	betNumList      []float64
	roundMaxPlayers uint32
	records         []*RoundRecord
	poolAmt         string
}

func (l *BaseLogic) Init(s *module.Skeleton, gameId uint64) {
	l.gameId = gameId
	l.roundNo = 0
	l.state = StateIdle
	l.userPos = make(map[string]int32)
	l.roomBets = make(map[int32]float64)
	l.userBets = make(map[string]float64)
	l.atkRoomIdStats = make(map[int32]int32)
	l.records = make([]*RoundRecord, 0)
	l.betNumList = make([]float64, 0)
	l.skeleton = s
	l.atkRooms = make([]int32, 0)
}

func (l *BaseLogic) ResetRoundData() {
	l.atkRooms = make([]int32, 0)
	l.roomBets = make(map[int32]float64)
	l.userBets = make(map[string]float64)
	for uid := range l.userPos {
		ur := UserMgr.GetUser(uid)
		if ur == nil || ur.Offline {
			UserMgr.DelUser(uid)
			delete(l.userPos, uid)

			// 同步在线玩家
			UserMgr.BroadCast(&msg.LeaveNtf{UserId: uid})
		} else {
			l.userPos[uid] = -1
			ur.BetData.Reset()
		}
	}
}

func (l *BaseLogic) saveGameData() {
	base.RedisHSet(&GameData{
		GameId:         l.gameId,
		RoundNo:        l.roundNo,
		RoundStartTime: l.roundStartTime.Unix(),
		State:          l.state,
		StateStartTime: l.stateStartTime.Unix(),
		RoomBets:       l.roomBets,
		UserBets:       l.userBets,
		UserPos:        l.userPos,
		AtkRoomStats:   l.atkRoomIdStats,
		AtkRooms:       l.atkRooms,
	})
}

func (l *BaseLogic) StartRound(roundNo int64) {
	l.ResetRoundData()
	l.roundStartTime = time.Now()
	l.state = StateBets
	l.stateStartTime = time.Now()
	l.roundNo = roundNo
	syncMsg := &msg.StartBetsNtf{
		State:   l.state,
		RoundNo: l.roundNo,
	}
	UserMgr.BroadCast(syncMsg)

	l.saveGameData()
	log.Debug("round: %d, start bets", l.roundNo)
}

func (l *BaseLogic) StartCountDown() {
	l.state = StateCountDown
	l.stateStartTime = time.Now()
	ntf := &msg.CountDownNtf{
		State:            l.state,
		CountDownEndTime: int64(l.countDownSecond),
	}
	UserMgr.BroadCast(ntf)
	l.saveGameData()
	log.Debug("round: %d, state to countdown", l.roundNo)
}

func (l *BaseLogic) StartSettle() {
	l.state = StateSettle
	l.stateStartTime = time.Now()
	ntf := &msg.SettleNtf{State: StateSettle}
	UserMgr.BroadCast(ntf)
	l.saveGameData()
	log.Debug("round: %d, state to settle", l.roundNo)
}

func (l *BaseLogic) StartResulting(atkSteps []int32, data interface{}) {
	l.state = StateResult
	l.stateStartTime = time.Now()
	l.stateEndTime = l.stateStartTime.Add(ResultTime)
	l.atkRooms = atkSteps

	l.saveGameData()
	roundRecord := &RoundRecord{
		RoundNo:   l.roundNo,
		AtkRooms:  atkSteps,
		StartTime: l.roundStartTime.Unix(),
		EndTime:   time.Now().Unix(),
	}
	base.RedisHSet(roundRecord)
	l.records = append(l.records, roundRecord)
	for _, rid := range atkSteps {
		l.atkRoomIdStats[rid]++
	}

	UserMgr.BroadToGuests(&msg.ResultNtf{
		State:        l.state,
		AtkRooms:     atkSteps,
		ResultStatus: msg.ResultStatusNotJoin,
	})
	log.Debug("round: %d, state to result", l.roundNo)
}

func (l *BaseLogic) SyncBetResult(userId string, txHash string, betAmt float64, roundNo int64, roomId int32) {

	log.Debug("sync bet result: user:%s betAmt:%v tx hash:%s", userId, betAmt, txHash)

	base.RedisHSetMerged(&UserBetData{
		UserId:      userId,
		RoundNo:     roundNo,
		BetAmt:      betAmt,
		TxHash:      txHash,
		BetRoomId:   roomId,
		Status:      msg.TradeStatusDone,
		TradeResult: msg.TradeResultOk,
	})

	UserMgr.SendMsg(userId, &msg.SyncBetResult{
		UserId:      userId,
		TradeHash:   txHash,
		TradeResult: msg.TradeResultOk,
		ErrMsg:      "trade success",
		BetAmt:      fmt.Sprint(betAmt),
	})

	if l.roundNo != roundNo {
		log.Error("sync err, round %d not match %d", roundNo, l.roundNo)
		return
	}

	checkRoomId := l.userPos[userId]
	l.userBets[userId] = betAmt
	l.userPos[userId] = roomId
	roomBetsTotal := l.roomBets[roomId] + betAmt
	l.roomBets[roomId] = roomBetsTotal

	// 如果room不一致，以上链结果同步
	if checkRoomId != roomId {
		UserMgr.BroadCast(&msg.MoveNtf{
			UserId: userId,
			From:   checkRoomId,
			To:     roomId,
		})
	}

	roomBets := make([]msg.RoomInfo, 0)
	for rid, bets := range l.roomBets {
		roomBets = append(roomBets, msg.RoomInfo{
			RoomId: rid,
			Bets:   bets,
		})
	}

	UserMgr.BroadCast(&msg.SyncRoomBetsNtf{
		RoundNo:  l.roundNo,
		RoomBets: roomBets,
	})

	l.saveGameData()

	ur := UserMgr.GetUser(userId)
	if ur != nil {
		ur.BetData.Status = msg.TradeStatusDone
		ur.BetData.BetRoomId = roomId
		ur.BetData.BetAmt = betAmt
	}
}

func (l *BaseLogic) SyncBetFail(userId string, txHash string, roundNo int64) {

	log.Debug("sync bet failed, user %s, tx_hash: %s", userId, txHash)

	base.RedisHSet(&UserBetData{
		UserId:  userId,
		RoundNo: roundNo,
	})

	if l.roundNo != roundNo {
		log.Error("sync err, round %d not match %d", roundNo, l.roundNo)
		return
	}

	ur := UserMgr.GetUser(userId)
	if ur == nil {
		log.Error("user %s not online", userId)
		return
	}

	ur.BetData.Reset()
	ur.BetData.RoundNo = l.roundNo
	UserMgr.SendMsg(userId, &msg.SyncBetResult{
		UserId:      userId,
		TradeHash:   txHash,
		TradeResult: msg.TradeResultFail,
		ErrMsg:      "trade failed",
	})
	return
}

func (l *BaseLogic) Leave(userId string) {
	roomId, ok := l.userPos[userId]
	if !ok || roomId < 0 {
		delete(l.userPos, userId)
		UserMgr.DelUser(userId)
		UserMgr.BroadCast(&msg.LeaveNtf{UserId: userId})
	} else {
		UserMgr.Offline(userId)
	}
	log.Debug("user %s removed", userId)
}

func (l *BaseLogic) GetGameData() *msg.GameData {
	data := &msg.GameData{
		RoundNo:         l.roundNo,
		State:           l.state,
		RoomList:        make([]msg.RoomInfo, 0),
		UserList:        make([]msg.UserInfo, 0),
		AtkRooms:        l.atkRooms,
		BetAmtList:      l.betNumList,
		StateStartTime:  l.stateStartTime.Unix(),
		CountDownSecond: l.countDownSecond,
	}

	if l.state == StateCountDown {
		data.CountDownSecond = l.countDownSecond - int32(time.Now().Sub(l.stateStartTime).Seconds())
		if data.CountDownSecond <= 0 {
			data.CountDownSecond = 1
		}
	}

	for uid, rid := range l.userPos {
		userInfo := UserMgr.GetUserInfo(uid)
		if userInfo == nil {
			delete(l.userPos, uid)
			continue
		}
		data.UserList = append(data.UserList, msg.UserInfo{
			UserId:   userInfo.UserId,
			NickName: userInfo.GetName(),
			SkinId:   userInfo.SkinId,
			RoomId:   rid,
		})
	}
	for rid, bets := range l.roomBets {
		data.RoomList = append(data.RoomList, msg.RoomInfo{
			RoomId: rid,
			Bets:   bets,
		})
	}
	return data
}

func (l *BaseLogic) EnterGame(userId string, logic ILogic) error {
	u := UserMgr.GetUser(userId)
	if u == nil || u.Offline {
		return fmt.Errorf("user %s not found", userId)
	}

	roomId, ok := l.userPos[userId]
	if !ok {
		roomId = -1
		l.userPos[userId] = roomId
	}

	if u.IsNoneAgent() {
		ntf := &msg.EnterGameNtf{
			UserId:   u.Uid,
			NickName: u.GetName(),
			SkinId:   u.SkinId,
			RoomId:   roomId,
		}
		UserMgr.BroadCast(ntf)
		return nil
	}

	if u.BetData.RoundNo != l.roundNo {
		u.BetData.Reset()
	}

	u.BetData.RoundNo = l.roundNo
	u.BetData.UserId = userId
	base.RedisHGet(&u.BetData)

	if u.BetData.BetRoomId > 0 && u.BetData.Status == msg.TradeStatusDone {
		pos := u.BetData.BetRoomId
		l.userPos[userId] = pos
		if checkBetAmt, ok1 := l.userBets[userId]; !ok1 || checkBetAmt <= 0.0 {
			l.roomBets[pos] = l.roomBets[pos] + u.BetData.BetAmt

			roomBets := make([]msg.RoomInfo, 0)
			for rid, bets := range l.roomBets {
				roomBets = append(roomBets, msg.RoomInfo{
					RoomId: rid,
					Bets:   bets,
				})
			}

			UserMgr.BroadCast(&msg.SyncRoomBetsNtf{
				RoundNo:  l.roundNo,
				RoomBets: roomBets,
			})
		}
		l.userBets[userId] = u.BetData.BetAmt
	}

	data := logic.GetGameData()
	enterRsp := &msg.EnterGameRsp{
		ErrCode:  0,
		GameData: *data,
		MyInfo: msg.SelfUserInfo{
			UserId:   userId,
			NickName: u.GetName(),
			RoomId:   roomId,
			SkinId:   u.SkinId,
			Points:   u.Points,
			Coins:    u.Coins,
			Token:    u.Token,
			BetData:  *u.BetData.MsgBets(),
		},
	}
	UserMgr.SendMsg(userId, enterRsp)
	log.Debug("user %s enter rsp: %+v", userId, enterRsp)

	ntf := &msg.EnterGameNtf{
		UserId:   u.Uid,
		NickName: u.GetName(),
		SkinId:   u.SkinId,
		RoomId:   roomId,
	}
	UserMgr.BroadCast(ntf)
	return nil
}

func (l *BaseLogic) Move(userId string, to int32) {
	ur := UserMgr.GetUser(userId)
	if ur == nil {
		log.Error("user %s not in game", userId)
		return
	}

	fromRoomId, ok := l.userPos[userId]
	if !ok {
		UserMgr.SendMsg(userId, &msg.MoveRsp{
			ErrCode: msg.ErrCodeNotInRoom,
			Msg:     "user not in round",
		})
		log.Error("user %s not in round", userId)
		return
	}

	if l.state != StateBets && l.state != StateCountDown {
		return
	}

	if ur.BetData.BetAmt > 0 {
		rsp := &msg.MoveRsp{
			ErrCode: msg.ErrCodeForbiddenMove,
			Msg:     "forbidden move when has bets in room",
		}
		UserMgr.SendMsg(userId, rsp)
		return
	}

	l.userPos[userId] = to

	syncMsg := &msg.MoveNtf{
		UserId: userId,
		From:   fromRoomId,
		To:     to,
	}
	UserMgr.BroadCast(syncMsg)

	if !ur.IsNoneAgent() {
		log.Debug("user %s move from %d to %d", userId, fromRoomId, to)
	}
}

func (l *BaseLogic) Bets(userId string, betCoins float64, txHash string) error {
	rsp := &msg.BetRsp{}

	ur := UserMgr.GetUser(userId)
	if ur == nil {
		log.Error("user %s not in game", userId)
		rsp.ErrCode = msg.ErrCodeNotInGame
		UserMgr.SendMsg(userId, rsp)
		return fmt.Errorf("user %s not in game", userId)
	}

	roomId, ok := l.userPos[userId]
	if !ok {
		log.Error("user %s not in game", userId)
		rsp.ErrCode = msg.ErrCodeNotInGame
		UserMgr.SendMsg(userId, rsp)
		return fmt.Errorf("user %s not in game", userId)
	}

	if roomId <= 0 {
		log.Error("user %s not in any room", userId)
		rsp.ErrCode = msg.ErrCodeNotInRoom
		UserMgr.SendMsg(userId, rsp)
		return fmt.Errorf("user %s not in room", userId)
	}

	rsp.ErrCode = msg.ErrCodeOk
	UserMgr.SendMsg(userId, rsp)

	ur.BetData.UserId = userId
	ur.BetData.Status = msg.TradeStatusProcess
	ur.BetData.RoundNo = l.roundNo
	ur.BetData.BetRoomId = roomId
	ur.BetData.TxHash = txHash
	ur.BetData.BetAmt = betCoins
	ur.BetData.BetTime = time.Now().Unix()
	base.RedisHSet(&ur.BetData)
	log.Debug("user %s token: %s bets:%v in room:%d, txHash: %s", userId, ur.Token, betCoins, roomId, txHash)
	return nil
}

func (l *BaseLogic) GetRecords(userId string) {
	rsp := &msg.GetRecordRsp{
		GameRoundRecords: make([]msg.GameRoundRecord, 0),
		UserRoundRecords: make([]msg.UserRoundRecord, 0),
		AtkRoomIdStats:   make([]msg.AtkRoomStats, 0),
	}
	UserMgr.SendMsg(userId, rsp)
}

func (l *BaseLogic) GetRanks(userId string, rankType int32) {
	rsp := &msg.GetRankRsp{
		Top3Ranks:  make([]msg.RankItem, 0),
		RankType:   rankType,
		Ranks:      make([]msg.RankItem, 0),
		SelfRankNo: 0,
		SelfWinAmt: "",
		SelfPutAmt: "",
		PoolAmt:    "",
		RankDate:   "",
	}
	UserMgr.SendMsg(userId, rsp)
}

func TodayRankKey() string {
	date := time.Now().Format("2006-01-02")
	return fmt.Sprintf("today_rank:%s", date)
}

func YesterdayRankKey() string {
	date := time.Now().AddDate(0, 0, -1).Format("2006-01-02")
	return fmt.Sprintf("yesterday_rank:%s", date)
}

func GetRoomIdsByString(roomId string) []int32 {
	roomIds := strings.Split(roomId, ",")
	atkRoomIds := make([]int32, 0)
	for i, id := range roomIds {
		if i >= 3 {
			break
		}
		rid, _ := strconv.ParseInt(id, 10, 64)
		if rid <= 0 {
			continue
		}
		rid = ((rid - 1) % RoomNum) + 1
		atkRoomIds = append(atkRoomIds, int32(rid))
	}
	return atkRoomIds
}

func CheckRoomIds(roomIds []int32) bool {
	if len(roomIds) == 0 {
		return false
	}
	ok := true
	for _, rid := range roomIds {
		if rid <= 0 {
			ok = false
			break
		}
	}
	return ok
}
