package internal

import (
	"bs/base"
	"bs/msg"
	"fmt"
	"strconv"
)

type KvModel struct {
	tableName string
	K         string `json:"k"`
	V         string `json:"v"`
}

func NewKvModel(s string, k string) *KvModel {
	return &KvModel{tableName: s, K: k}
}

func (km *KvModel) TableName() string {
	return km.tableName
}

func (km *KvModel) PKName() string {
	return km.K
}

func (km *KvModel) ToBool() (bool, error) {
	if km.V == "" {
		return false, fmt.Errorf("kv not valued")
	}
	return strconv.ParseBool(km.V)
}

func (km *KvModel) ToInt64() (int64, error) {
	if km.V == "" {
		return 0, fmt.Errorf("kv not valued")
	}
	return strconv.ParseInt(km.V, 10, 64)
}

func (km *KvModel) ToFloat64() (float64, error) {
	if km.V == "" {
		return 0, fmt.Errorf("kv not valued")
	}
	return strconv.ParseFloat(km.V, 64)
}

type UserInfo struct {
	UserId   string `json:"user_id"`
	SkinId   int32  `json:"skin_id"`
	NickName string `json:"nick_name"`
}

func (u *UserInfo) TableName() string {
	return "user_info"
}

func (u *UserInfo) PKName() string {
	return u.UserId
}

func (u *UserInfo) GetName() string {
	if u.NickName != "" {
		return u.NickName
	}
	if len(u.UserId) > 4 {
		return u.UserId[:2] + "**" + u.UserId[len(u.UserId)-2:]
	}
	return u.UserId
}

type GameData struct {
	GameId         uint64             `json:"game_id"`
	RoundNo        int64              `json:"round_no"`
	RoundStartTime int64              `json:"round_start_time"`
	State          int32              `json:"state"`
	StateStartTime int64              `json:"state_start_time"`
	RoomBets       map[int32]float64  `json:"room_bets"`
	AtkRooms       []int32            `json:"atk_rooms"`
	UserBets       map[string]float64 `json:"user_bets"`
	UserPos        map[string]int32   `json:"user_pos"`
	AtkRoomStats   map[int32]int32    `json:"atk_room_stats"`
}

func (r *GameData) PKName() string {
	return fmt.Sprint(r.GameId)
}

func (r *GameData) TableName() string {
	return "game_data"
}

type RoundRecord struct {
	RoundNo   int64   `json:"round_no"`
	AtkRooms  []int32 `json:"atk_rooms"`
	StartTime int64   `json:"start_time"`
	EndTime   int64   `json:"end_time"`
}

func (r *RoundRecord) PKName() string {
	return fmt.Sprint(r.RoundNo)
}

func (r *RoundRecord) TableName() string {
	return "round_record"
}

type UserBetData struct {
	UserId        string  `json:"user_id"`
	RoundNo       int64   `json:"round_no"`
	BetRoomId     int32   `json:"bet_room_id"`
	BetAmt        float64 `json:"bet_amt"`
	TxHash        string  `json:"tx_hash"`
	BetTime       int64   `json:"bet_time"`
	Status        int32   `json:"status"`
	AtkRooms      []int32 `json:"atk_rooms"`
	WinAmt        float64 `json:"win_amt"`
	GetScore      float64 `json:"get_score"`
	TradeResult   int32   `json:"trade_result"`
	SettleHash    string  `json:"settle_hash"`
	LockHash      string  `json:"lock_hash"`
	LockTime      int64   `json:"lock_time"`
	LockBlockHash string  `json:"lock_block_hash"`
	RandomGenTime int64   `json:"random_gen_time"`
	AdminAddress  string  `json:"admin_address"`
}

func (r *UserBetData) Reset() {
	r.RoundNo = 0
	r.BetAmt = 0
	r.BetRoomId = 0
	r.TxHash = ""
	r.BetTime = 0
	r.Status = 0
	r.AtkRooms = make([]int32, 0)
	r.WinAmt = 0
	r.GetScore = 0
	r.TradeResult = 0
}

func (r *UserBetData) MsgBets() *msg.BetData {
	return &msg.BetData{
		Status: r.Status,
		RoomId: r.BetRoomId,
		BetAmt: r.BetAmt,
	}
}

func (r *UserBetData) Save() {
	base.RedisHSetMerged(r)
}

func (r *UserBetData) TableName() string {
	return "user_bets"
}

func (r *UserBetData) PKName() string {
	if r.UserId == "" || r.RoundNo == 0 {
		return ""
	}
	return fmt.Sprintf("%s_%d", r.UserId, r.RoundNo)
}

func (r *UserBetData) Merge(leftData base.IMergeModel) {
	l, ok := leftData.(*UserBetData)
	if !ok {
		return
	}
	if r.BetRoomId == 0 && l.BetRoomId > 0 {
		r.BetRoomId = l.BetRoomId
	}
	if r.BetAmt == 0.0 && l.BetAmt > 0 {
		r.BetAmt = l.BetAmt
	}
	if r.TxHash == "" && l.TxHash != "" {
		r.TxHash = l.TxHash
	}
	if r.BetTime == 0 && l.BetTime > 0 {
		r.BetTime = l.BetTime
	}
	if r.Status == 0 && l.Status > 0 {
		r.Status = l.Status
	}
	if len(r.AtkRooms) == 0 && len(l.AtkRooms) > 0 {
		r.AtkRooms = l.AtkRooms
	}
	if r.WinAmt == 0.0 && l.WinAmt > 0 {
		r.WinAmt = l.WinAmt
	}
	if r.GetScore == 0.0 && l.GetScore > 0 {
		r.GetScore = l.GetScore
	}
	if r.TradeResult == 0 && l.TradeResult > 0 {
		r.TradeResult = l.TradeResult
	}
}

func (r *UserBetData) NewMergeData() base.IMergeModel {
	return &UserBetData{UserId: r.UserId, RoundNo: r.RoundNo}
}
