package internal

import (
	"bs/base"
	"bs/conf"
	"github.com/name5566/leaf/module"
)

var (
	skeleton = base.NewSkeleton()
	ChanRPC  = skeleton.ChanRPCServer
)

type Module struct {
	*module.Skeleton
}

func (m *Module) OnInit() {
	m.Skeleton = skeleton
	NewUserMgr()
	base.SetupRedis(conf.Server.RedisAddr, "dts")
	base.SetupDataQueue()
	SetLogic(m.Skeleton)
	SetupAi(m.Skeleton)
}

func (m *Module) OnDestroy() {

}
