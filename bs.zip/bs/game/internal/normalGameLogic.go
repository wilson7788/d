package internal

import (
	"bs/base"
	"bs/msg"
	"fmt"
	"github.com/name5566/leaf/log"
	"github.com/name5566/leaf/module"
	"math/rand"
	"time"
)

type NormalLogic struct {
	BaseLogic
}

func (nl *NormalLogic) InitLogic(s *module.Skeleton, gameId uint64) error {
	nl.Init(s, gameId)
	nl.betNumList = []float64{10, 50, 100}
	nl.roundMaxPlayers = 50
	nl.countDownSecond = 30
	nl.roundNo = 0
	nl.state = StateIdle

	gameData := &GameData{GameId: nl.gameId}
	err := base.RedisHGet(gameData)
	if err == nil {
		nl.roundNo = gameData.RoundNo
		nl.roundStartTime = time.Unix(gameData.RoundStartTime, 0)
		nl.stateStartTime = time.Unix(gameData.StateStartTime, 0)
		nl.state = gameData.State
		nl.atkRooms = gameData.AtkRooms
		if len(gameData.RoomBets) > 0 {
			nl.roomBets = gameData.RoomBets
		}
		if len(gameData.UserPos) > 0 {
			nl.userPos = gameData.UserPos
		}
		if len(gameData.UserBets) > 0 {
			nl.userBets = gameData.UserBets
		}
		if len(gameData.AtkRoomStats) > 0 {
			nl.atkRoomIdStats = gameData.AtkRoomStats
		}
		for userId := range nl.userPos {
			if _, ok := nl.userBets[userId]; !ok {
				delete(nl.userPos, userId)
			}
		}

		tmpRecords := make([]*RoundRecord, 0)
		for i, l := nl.roundNo, 0; i > 0 && l < 10; i-- {
			round := &RoundRecord{RoundNo: i}
			er := base.RedisHGet(round)
			if er != nil {
				continue
			}
			tmpRecords = append(tmpRecords, round)
			l++
		}
		for i := len(tmpRecords) - 1; i > 0; i-- {
			nl.records = append(nl.records, tmpRecords[i])
		}

		switch nl.state {
		case StateIdle:
			nl.skeleton.AfterFunc(time.Second, nl.onStartRound)
			break
		case StateBets:
			nl.skeleton.AfterFunc(BetsTime, nl.onStartCountDown)
			break
		case StateCountDown:
			nl.skeleton.AfterFunc(time.Duration(nl.countDownSecond)*time.Second, nl.onStartSettle)
			break
		case StateSettle:
			nl.skeleton.AfterFunc(SettleTime, nl.onStartResulting)
			break
		case StateResult:
			nl.skeleton.AfterFunc(ResultTime, nl.onStartRound)
			break
		}
	} else {
		nl.skeleton.AfterFunc(time.Second, nl.onStartRound)
	}
	log.Debug("game state sync ok, round: %d, current state: %d", nl.roundNo, nl.state)
	return nil
}

func (nl *NormalLogic) onStartRound() {
	nl.StartRound(nl.roundNo + 1)
	nl.skeleton.AfterFunc(BetsTime, nl.onStartCountDown)
}

func (nl *NormalLogic) onStartCountDown() {
	nl.StartCountDown()
	nl.skeleton.AfterFunc(time.Duration(nl.countDownSecond)*time.Second, nl.onStartSettle)
}

func (nl *NormalLogic) onStartSettle() {
	nl.StartSettle()
	nl.skeleton.AfterFunc(SettleTime, nl.onStartResulting)
}

func (nl *NormalLogic) onStartResulting() {
	atkSteps := make([]int32, 2)
	atkSteps[0] = rand.Int31n(RoomNum/2) + 1
	atkSteps[1] = RoomNum/2 + rand.Int31n(RoomNum/2) + 1
	nl.StartResulting(atkSteps, nil)
	nl.skeleton.AfterFunc(ResultTime, nl.onStartRound)
}

func (nl *NormalLogic) StartResulting(atkSteps []int32, data interface{}) {
	nl.BaseLogic.StartResulting(atkSteps, data)

	for userId, roomId := range nl.userPos {
		betAmt, _ := nl.userBets[userId]
		ntf := &msg.ResultNtf{
			UserId:       userId,
			State:        nl.state,
			AtkRooms:     atkSteps,
			WinAmt:       betAmt,
			GetPoints:    betAmt * 100,
			ResultStatus: msg.ResultStatusNotJoin,
		}

		if betAmt > 0 {

			beAttacked := false
			for _, rid := range atkSteps {
				if roomId == rid {
					beAttacked = true
					break
				}
			}

			if !beAttacked {
				ntf.ResultStatus = msg.ResultStatusSuccess
			} else {
				ntf.ResultStatus = msg.ResultStatusFail
			}

			ur := UserMgr.GetUser(userId)
			if ur == nil {
				base.RedisHSetMerged(&UserBetData{
					UserId:    userId,
					RoundNo:   nl.roundNo,
					BetRoomId: rand.Int31n(RoomNum-1) + 1,
					WinAmt:    ntf.WinAmt,
					BetAmt:    ntf.WinAmt,
					GetScore:  float64(ntf.GetPoints),
					AtkRooms:  atkSteps,
					BetTime:   time.Now().Unix(),
				})
			} else if ur.IsNoneAgent() == false {
				ur.BetData.RoundNo = nl.roundNo
				ur.BetData.UserId = userId
				ur.BetData.Status = msg.TradeStatusDone
				ur.BetData.WinAmt = ntf.WinAmt
				ur.BetData.GetScore = ntf.GetPoints
				ur.BetData.AtkRooms = atkSteps
				base.RedisHSetMerged(&ur.BetData)
			}
		}
		UserMgr.SendMsg(userId, ntf)
	}
}

func (nl *NormalLogic) Enter(userId string) (err error) {

	defer func() {
		if err != nil {
			UserMgr.SendMsg(userId, &msg.EnterGameRsp{ErrCode: msg.ErrCodeInvalidAuth})
		}
	}()

	userInfo := &UserInfo{UserId: userId}
	if er1 := base.RedisHGet(userInfo); er1 != nil {
		userInfo.SkinId = rand.Int31n(SkinNum) + 1
		userInfo.NickName = ""
		base.RedisHSet(userInfo)
	}

	return nl.BaseLogic.EnterGame(userId, nl)
}

func (nl *NormalLogic) Bets(userId string, betCoins float64, txHash string) (err error) {

	defer func() {
		if err != nil {
			UserMgr.SendMsg(userId, &msg.BetRsp{ErrCode: msg.ErrCodeInvalidAuth})
		}
	}()

	roomId, ok := nl.userPos[userId]
	if !ok {
		UserMgr.SendMsg(userId, &msg.BetRsp{ErrCode: msg.ErrCodeNotInRoom, ErrMsg: "NOT select a cell"})
		return nil
	}

	err = nl.BaseLogic.Bets(userId, betCoins, txHash)
	if err != nil {
		return err
	}

	nl.SyncBetResult(userId, txHash, betCoins, nl.roundNo, roomId)
	return nil
}

func (nl *NormalLogic) GetRecords(userId string) {
	rsp := &msg.GetRecordRsp{
		GameRoundRecords: make([]msg.GameRoundRecord, 0),
		UserRoundRecords: make([]msg.UserRoundRecord, 0),
		AtkRoomIdStats:   make([]msg.AtkRoomStats, 0),
	}

	for rid, num := range nl.atkRoomIdStats {
		rsp.AtkRoomIdStats = append(rsp.AtkRoomIdStats, msg.AtkRoomStats{
			RoomId: rid,
			AtkNum: num,
		})
	}

	for i, l := nl.roundNo, 0; i > 0 && l < 10; i-- {
		record := &RoundRecord{RoundNo: i}
		if er := base.RedisHGet(record); er != nil {
			continue
		}
		if len(record.AtkRooms) == 0 {
			continue
		}
		l++
		rsp.GameRoundRecords = append(rsp.GameRoundRecords, msg.GameRoundRecord{
			RoundNo:  record.RoundNo,
			AtkRooms: record.AtkRooms,
		})
	}

	for i, l := nl.roundNo, 0; i > 0 && l < 10; i-- {
		userRecord := &UserBetData{UserId: userId, RoundNo: i}
		err := base.RedisHGet(userRecord)
		if err == nil {

			isWin := true
			for _, rid := range userRecord.AtkRooms {
				if userRecord.BetRoomId == rid {
					isWin = false
					break
				}
			}

			rsp.UserRoundRecords = append(rsp.UserRoundRecords, msg.UserRoundRecord{
				UserId:     userRecord.UserId,
				RoundNo:    userRecord.RoundNo,
				StayRoomId: userRecord.BetRoomId,
				AtkRooms:   userRecord.AtkRooms,
				BetAmt:     userRecord.BetAmt,
				WinAmt:     userRecord.WinAmt,
				Points:     userRecord.GetScore,
				RoundTime:  userRecord.BetTime * 1000,
				IsWin:      isWin,
			})
			l++
		}
	}
	log.Debug("records: %+v", rsp)
	UserMgr.SendMsg(userId, rsp)
}

func (nl *NormalLogic) GetRanks(userId string, rankType int32) {
	rsp := &msg.GetRankRsp{
		Top3Ranks:  make([]msg.RankItem, 0),
		RankType:   rankType,
		Ranks:      make([]msg.RankItem, 0),
		SelfRankNo: rand.Int31n(10) + 1,
		SelfWinAmt: fmt.Sprint(rand.Int31n(100)),
		SelfPutAmt: fmt.Sprint(rand.Int31n(1000)),
		PoolAmt:    "10000",
		RankDate:   "",
	}

	for i, l := 0, 3; i < l; i++ {
		rsp.Top3Ranks = append(rsp.Top3Ranks, msg.RankItem{
			SortNo:  int32(i + 1),
			Name:    fmt.Sprintf("0x%02d**%04d", rand.Int31n(100), rand.Int31n(10000)),
			SkinId:  rand.Int31n(SkinNum) + 1,
			PutInto: fmt.Sprint(rand.Int31n(100)),
			WinAmt:  fmt.Sprint(rand.Int31n(100)),
		})
	}
	if rankType == 1 {
		rsp.Ranks = rsp.Top3Ranks[0:]
		for i, l := 3, 10; i < l; i++ {
			rsp.Ranks = append(rsp.Ranks, msg.RankItem{
				SortNo:  int32(i + 1),
				Name:    fmt.Sprintf("0x%02d**%04d", rand.Int31n(100), rand.Int31n(10000)),
				SkinId:  rand.Int31n(SkinNum) + 1,
				PutInto: fmt.Sprint(rand.Int31n(100)),
				WinAmt:  fmt.Sprint(rand.Int31n(100)),
			})
		}
	} else {
		for i, l := 0, 10; i < l; i++ {
			rsp.Ranks = append(rsp.Ranks, msg.RankItem{
				SortNo:  int32(i + 1),
				Name:    fmt.Sprintf("0x%02d**%04d", rand.Int31n(100), rand.Int31n(10000)),
				SkinId:  rand.Int31n(SkinNum) + 1,
				PutInto: fmt.Sprint(rand.Int31n(100)),
			})
		}
	}

	UserMgr.SendMsg(userId, rsp)
}
