package internal

import (
	"bs/base"
	"github.com/name5566/leaf/gate"
	"github.com/name5566/leaf/log"
	"sync"
	"time"
)

const (
	SkinNum = 4
)

var UserMgr *UMgr

type User struct {
	Uid      string
	Agent    gate.Agent
	Points   int64
	Coins    float64
	NickName string
	Level    int32
	Token    string
	SkinId   int32
	Offline  bool
	OffTime  int64
	LastTime time.Time
	BetData  UserBetData
}

func (u *User) IsAuth() bool {
	return u.Token != ""
}

func (u *User) IsNoneAgent() bool {
	return u.Agent == nil
}

func (u *User) WriteMsg(msg interface{}) {
	if u.Agent != nil && !u.Offline {
		u.Agent.WriteMsg(msg)
	}
}

func (u *User) GetName() string {
	if u.NickName != "" {
		return u.NickName
	}
	if len(u.Uid) > 4 {
		return u.Uid[:2] + "**" + u.Uid[len(u.Uid)-2:]
	}
	return u.Uid
}

type UMgr struct {
	sync.RWMutex
	userList map[string]*User
	agents   map[gate.Agent]gate.Agent
}

func NewUserMgr() {
	UserMgr = &UMgr{
		userList: make(map[string]*User),
		agents:   make(map[gate.Agent]gate.Agent),
	}
}

func (um *UMgr) AddAgent(agt gate.Agent) {
	um.Lock()
	defer um.Unlock()
	um.agents[agt] = agt
	log.Debug("agent %s register", agt.RemoteAddr().String())
}

func (um *UMgr) DelAgent(agt gate.Agent) {
	um.Lock()
	defer um.Unlock()
	delete(um.agents, agt)
	log.Debug("agent %s unRegister", agt.RemoteAddr().String())
}

func (um *UMgr) NewUser(agent gate.Agent, userId string) *User {
	um.Lock()
	defer um.Unlock()
	u, ok := um.userList[userId]
	if !ok {
		u = &User{
			Uid:      userId,
			Token:    userId,
			Agent:    agent,
			Points:   0,
			Coins:    0,
			Offline:  false,
			OffTime:  0,
			LastTime: time.Now(),
		}
		userInfo := &UserInfo{UserId: userId}
		if err := base.RedisHGet(userInfo); err == nil {
			u.SkinId = userInfo.SkinId
			u.NickName = userInfo.NickName
		} else {
			u.SkinId = 1
			u.NickName = ""
		}
		um.userList[userId] = u
	} else {
		if u.Agent != nil && u.Agent != agent {
			u.Agent.Close()
			u.Agent = nil
		}
		u.Token = userId
		u.Agent = agent
		u.Offline = false
		u.OffTime = 0
		u.LastTime = time.Now()
	}
	return u
}

func (um *UMgr) GetUser(uid string) *User {
	um.Lock()
	defer um.Unlock()
	if u, ok := um.userList[uid]; ok {
		return u
	}
	return nil
}

func (um *UMgr) GetUserInfo(uid string) *UserInfo {
	u := um.GetUser(uid)
	if u != nil {
		return &UserInfo{
			UserId:   u.Uid,
			SkinId:   u.SkinId,
			NickName: u.NickName,
		}
	}
	userInfo := &UserInfo{UserId: uid}
	err := base.RedisHGet(userInfo)
	if err != nil {
		return nil
	}
	return userInfo
}

func (um *UMgr) DelUser(uid string) {
	um.Lock()
	defer um.Unlock()
	if _, ok := um.userList[uid]; ok {
		delete(um.userList, uid)
	}
}

func (um *UMgr) Offline(uid string) {
	um.Lock()
	defer um.Unlock()
	u, ok := um.userList[uid]
	if !ok {
		return
	}
	u.Offline = true
	u.OffTime = time.Now().Unix()
	u.Agent = nil
	log.Debug("user %s offline", uid)
}

func (um *UMgr) BroadCast(msg interface{}) {
	um.RLock()
	defer um.RUnlock()
	for agt := range um.agents {
		agt.WriteMsg(msg)
	}
}

func (um *UMgr) BroadToGuests(msg interface{}) {
	um.RLock()
	defer um.RUnlock()
	for agt := range um.agents {
		userId, ok := agt.UserData().(string)
		if !ok || len(userId) == 0 {
			agt.WriteMsg(msg)
		}
	}
}

func (um *UMgr) SendMsg(userId string, msg interface{}) {
	ur := um.GetUser(userId)
	if ur == nil {
		log.Error("user %s not found", userId)
		return
	}
	if ur.Offline {
		log.Error("user %s offline, ignore send msg", userId)
		return
	}
	ur.WriteMsg(msg)
}
