package game

import (
	"bs/game/internal"
	"bs/msg/pb_bs"
	"context"
	"github.com/name5566/leaf/log"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	"net"
	"strconv"
)

func SetupService(network, address string) {
	// 监听本地端口
	listener, err := net.Listen(network, address)
	if err != nil {
		log.Fatal("address %s listen error:%v", address, err)
	}
	log.Debug("network: %s listen on: %s", network, address)
	// 新建gRPC服务器实例
	grpcServer := grpc.NewServer()
	reflection.Register(grpcServer)
	// 在gRPC服务器注册我们的服务
	pb_bs.RegisterBsServer(grpcServer, &BsService{})

	go func() {
		//用服务器 Serve() 方法以及我们的端口信息区实现阻塞等待，直到进程被杀死或者 Stop() 被调用
		err = grpcServer.Serve(listener)
		if err != nil {
			log.Fatal("grpcServer.Serve err: %v", err)
		}
	}()
}

type BsService struct {
}

func (ds *BsService) StartRound(ctx context.Context, req *pb_bs.StartRoundReq) (*pb_bs.StartRoundRsp, error) {
	res := pb_bs.StartRoundRsp{
		Code: int32(pb_bs.ErrCode_Success),
	}

	roundNo, err := strconv.ParseInt(req.Round, 10, 64)
	if err != nil {
		log.Error("rsp StartRound err: %+v", err)
		roundNo = 0
	}

	internal.Logic.StartRound(roundNo)
	log.Debug("Rpc: StartRound, req %+v", req)
	return &res, nil
}

func (ds *BsService) RoundCountDown(ctx context.Context, req *pb_bs.RoundCountDownReq) (*pb_bs.RoundCountDownRsp, error) {
	res := pb_bs.RoundCountDownRsp{
		Code:         int32(pb_bs.ErrCode_Success),
		WaitDuration: int64(internal.ResultTime.Seconds()),
	}

	internal.Logic.StartCountDown()
	log.Debug("Rpc: RoundCountDown, req: %+v", req)
	return &res, nil
}

func (ds *BsService) LockRound(ctx context.Context, req *pb_bs.LockRoundBetReq) (*pb_bs.LockRoundBetRsp, error) {
	res := pb_bs.LockRoundBetRsp{
		Code: 0,
	}

	internal.Logic.StartSettle()
	log.Debug("Rpc: LockRound, req: %+v", req)
	return &res, nil
}

func (ds *BsService) SyncResult(ctx context.Context, req *pb_bs.SyncRoundResultReq) (*pb_bs.SyncRoundResultRsp, error) {
	res := pb_bs.SyncRoundResultRsp{
		Code: 0,
	}

	atkSteps := internal.GetRoomIdsByString(req.RoomIds)
	internal.Logic.StartResulting(atkSteps, req)
	log.Debug("Rpc: SyncResult, req: %+v", req)
	return &res, nil
}

func (ds *BsService) SyncBetData(ctx context.Context, req *pb_bs.SyncBetDataReq) (*pb_bs.SyncBetDataRsp, error) {
	res := pb_bs.SyncBetDataRsp{
		Code: 0,
	}
	if len(req.SyncBetResult) > 0 {
		for _, betResult := range req.SyncBetResult {
			betAmt, err := strconv.ParseFloat(betResult.BetAmount, 64)
			if err != nil {
				log.Error("bet amount invalid")
			}
			roundNo, _ := strconv.ParseInt(req.Round, 10, 64)
			roomId, _ := strconv.ParseInt(betResult.CellIndex, 10, 64)
			internal.Logic.SyncBetResult(betResult.Uid, betResult.TxHash, betAmt, roundNo, int32(roomId))
		}
	}
	log.Debug("rpc SyncBetData, req: %+v", req)
	return &res, nil
}

func (ds *BsService) BetFail(ctx context.Context, req *pb_bs.BetFailReq) (*pb_bs.BetFailRsp, error) {
	res := pb_bs.BetFailRsp{
		Code: 0,
	}
	roundNo, _ := strconv.ParseInt(req.Round, 10, 64)
	internal.Logic.SyncBetFail(req.Uid, req.TxHash, roundNo)
	log.Debug("rpc BetFail, req: %+v", req)
	return &res, nil
}

func (ds *BsService) SyncConfig(ctx context.Context, req *pb_bs.SyncConfigReq) (*pb_bs.SyncConfigRsp, error) {
	rsp := pb_bs.SyncConfigRsp{Code: 0}
	return &rsp, nil
}
