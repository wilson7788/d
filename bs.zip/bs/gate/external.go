package gate

import "bs/gate/internal"

var (
	Module = new(internal.Module)
)
