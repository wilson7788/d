package gate

import (
	"bs/game"
	"bs/msg"
)

func init() {
	msg.Processor.SetRouter(&msg.EnterGameReq{}, game.ChanRPC)
	msg.Processor.SetRouter(&msg.MoveReq{}, game.ChanRPC)
	msg.Processor.SetRouter(&msg.BetReq{}, game.ChanRPC)
	msg.Processor.SetRouter(&msg.GetRecordReq{}, game.ChanRPC)
	msg.Processor.SetRouter(&msg.HeartBeat{}, game.ChanRPC)
	msg.Processor.SetRouter(&msg.GetRankReq{}, game.ChanRPC)
}
