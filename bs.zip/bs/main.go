package main

import (
	"bs/conf"
	"bs/game"
	"bs/gate"
	"github.com/name5566/leaf"
	leafConf "github.com/name5566/leaf/conf"
	_ "net/http/pprof"
)

func main() {
	leafConf.LogLevel = conf.Server.LogLevel
	leafConf.LogPath = conf.Server.LogPath
	leafConf.LogFlag = conf.LogFlag
	leafConf.ConsolePort = conf.Server.ConsolePort
	leafConf.ProfilePath = conf.Server.ProfilePath

	game.SetupService(conf.Server.ServiceNetwork, conf.Server.ServiceAddress)

	leaf.Run(
		game.Module,
		gate.Module,
	)
}
