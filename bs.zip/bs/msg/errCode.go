package msg

const (
	ErrCodeOk                  = 0
	ErrCodeInvalidAuth         = 1
	ErrCodeNotInGame           = 2
	ErrCodeNotInRoom           = 3
	ErrCodeInsufficientBalance = 4
	ErrCodeForbiddenMove       = 5
	ErrCodeRoundPlayersLimit   = 6
)
