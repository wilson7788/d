package msg

import (
	"github.com/name5566/leaf/network/json"
)

var Processor = json.NewProcessor()

func init() {
	Processor.Register(&EnterGameReq{})
	Processor.Register(&EnterGameRsp{})
	Processor.Register(&EnterGameNtf{})
	Processor.Register(&MoveReq{})
	Processor.Register(&MoveNtf{})
	Processor.Register(&MoveRsp{})
	Processor.Register(&LeaveNtf{})
	Processor.Register(&StartBetsNtf{})
	Processor.Register(&CountDownNtf{})
	Processor.Register(&SettleNtf{})
	Processor.Register(&ResultNtf{})
	Processor.Register(&BetReq{})
	Processor.Register(&BetRsp{})
	Processor.Register(&SyncBetResult{})
	Processor.Register(&SyncRoomBetsNtf{})
	Processor.Register(&GetRecordReq{})
	Processor.Register(&GetRecordRsp{})
	Processor.Register(&HeartBeat{})
	Processor.Register(&GetRankReq{})
	Processor.Register(&GetRankRsp{})
}
