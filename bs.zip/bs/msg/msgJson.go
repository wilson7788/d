package msg

const TradeResultNone = 0
const TradeResultOk = 0
const TradeResultFail = 1

const TradeStatusNone = 0
const TradeStatusProcess = 1
const TradeStatusDone = 2

type UserInfo struct {
	UserId   string `json:"user_id"`
	NickName string `json:"nick_name"`
	SkinId   int32  `json:"skin_id"`
	RoomId   int32  `json:"room_id"`
}

type RoomInfo struct {
	RoomId int32   `json:"room_id"`
	Bets   float64 `json:"bets"`
}

type BetData struct {
	Status int32   `json:"status"`
	RoomId int32   `json:"room_id"`
	BetAmt float64 `json:"bet_amt"`
}

// 游戏主角的玩家信息
type SelfUserInfo struct {
	UserId   string  `json:"user_id"`
	NickName string  `json:"nick_name"`
	RoomId   int32   `json:"room_id"`
	SkinId   int32   `json:"skin_id"` // 皮肤id
	Points   int64   `json:"points"`  // 游戏积分
	Coins    float64 `json:"coins"`
	Token    string  `json:"token"`    // 平台登陆授权的用户token
	BetData  BetData `json:"bet_data"` // 玩家的下注信息
}

type GameData struct {
	ChainBlockAddress string     `json:"chain_block_address"` // 合约地址
	ChainId           string     `json:"chain_id"`
	RoundNo           int64      `json:"round_no"`
	State             int32      `json:"state"` // 0-idle 1-start 2-countdown 3-settle 4-result
	UserList          []UserInfo `json:"user_list"`
	RoomList          []RoomInfo `json:"room_list"`
	AtkRooms          []int32    `json:"atk_rooms"`
	BetAmtList        []float64  `json:"bet_amt_list"` // 下注金额列表
	StateStartTime    int64      `json:"state_start_time"`
	CountDownSecond   int32      `json:"count_down_end_time"`
}

type EnterGameReq struct {
	Token  string `json:"token"`
	Lang   string `json:"lang"`
	Invite string `json:"invite"`
}

type EnterGameRsp struct {
	ErrCode  int32        `json:"err_code"`
	GameData GameData     `json:"game_data"`
	MyInfo   SelfUserInfo `json:"my_info"`
}

type EnterGameNtf struct {
	UserId   string `json:"user_id"`
	NickName string `json:"nick_name"`
	SkinId   int32  `json:"skin_id"`
	RoomId   int32  `json:"room_id"`
}

type MoveReq struct {
	UserId string `json:"user_id"`
	To     int32  `json:"to"`
}

type MoveRsp struct {
	ErrCode int32  `json:"err_code"`
	Msg     string `json:"msg"`
}

type MoveNtf struct {
	UserId string `json:"user_id"`
	From   int32  `json:"from"`
	To     int32  `json:"to"`
}

type LeaveNtf struct {
	UserId string `json:"user_id"`
}

type BetReq struct {
	UserId    string  `json:"user_id"`
	RoundNo   int64   `json:"round_no"`
	RoomId    int32   `json:"room_id"`
	BetAmt    float64 `json:"bet_amt"`
	TradeHash string  `json:"trade_hash"`
}

type BetRsp struct {
	ErrCode int32  `json:"err_code"` // 押注成功后客户端表现交易提交中， 游戏等待主站通知trade hash的交易结果
	ErrMsg  string `json:"err_msg"`
}

type SyncBetResult struct {
	UserId      string `json:"user_id"`
	TradeHash   string `json:"trade_hash"`
	TradeResult int32  `json:"trade_result"` // 0 成功 1 失败
	ErrMsg      string `json:"err_msg"`      // 如果失败 err msg 携带失败信息
	BetAmt      string `json:"bet_amt"`
}

type SyncRoomBetsNtf struct {
	RoundNo  int64      `json:"round_no"`
	RoomBets []RoomInfo `json:"room_bets"`
}

type StartBetsNtf struct {
	State   int32 `json:"state"`
	RoundNo int64 `json:"round_no"`
}

type CountDownNtf struct {
	State            int32 `json:"state"`
	CountDownEndTime int64 `json:"count_down_end_time"` // 押注倒计时结束时间
}

type SettleNtf struct {
	State int32 `json:"state"`
}

const (
	ResultStatusNone    = 0
	ResultStatusSuccess = 1
	ResultStatusFail    = 2
	ResultStatusNotJoin = 3
)

type ResultNtf struct {
	UserId       string  `json:"user_id"`
	State        int32   `json:"state"`
	AtkRooms     []int32 `json:"atk_rooms"`
	GetPoints    float64 `json:"get_points"`    // 本轮获得的积分
	WinAmt       float64 `json:"win_amt"`       // 本轮押注的收益
	ResultStatus int32   `json:"result_status"` // 1 胜利 2 失败 3 没有参加
}

type GameRoundRecord struct {
	RoundNo  int64   `json:"round_no"`
	AtkRooms []int32 `json:"atk_rooms"`
}

type UserRoundRecord struct {
	UserId        string  `json:"user_id"`
	RoundNo       int64   `json:"round_no"`
	StayRoomId    int32   `json:"stay_room_id"` // 本轮玩家躲避的房间
	AtkRooms      []int32 `json:"atk_rooms"`    // 本轮被攻击的房间
	BetAmt        float64 `json:"bet_amt"`      // 本轮押注的金额
	WinAmt        float64 `json:"win_amt"`      // 本轮收益的金额
	Points        float64 `json:"points"`       // 本轮玩家获得的积分
	RoundTime     int64   `json:"round_time"`   // 本轮的游戏开始时间
	IsWin         bool    `json:"is_win"`       // 躲避是否成功
	SettleHash    string  `json:"settle_hash"`
	LockHash      string  `json:"lock_hash"`
	LockTime      int64   `json:"lock_time"`
	LockBlockHash string  `json:"lock_block_hash"`
	RandomGenTime int64   `json:"random_gen_time"`
	AdminAddress  string  `json:"admin_address"`
}

type GetRecordReq struct {
	UserId string `json:"user_id"`
}

type AtkRoomStats struct {
	RoomId int32 `json:"room_id"`
	AtkNum int32 `json:"atk_num"`
}

type GetRecordRsp struct {
	GameRoundRecords []GameRoundRecord `json:"game_round_records"` // 近10轮的攻击记录
	UserRoundRecords []UserRoundRecord `json:"user_round_records"` // 玩家的游戏记录
	AtkRoomIdStats   []AtkRoomStats    `json:"atk_room_id_stats"`  // 10个房间累计最近100场被攻击的次数
}

type GetRankReq struct {
	UserId   string `json:"user_id"`
	RankType int32  `json:"rank_type"` // 0今日 1昨日
}

type RankItem struct {
	UserId  string `json:"user_id"`
	SortNo  int32  `json:"sort_no"`
	Name    string `json:"name"`
	SkinId  int32  `json:"skin_id"`
	PutInto string `json:"put_into"`
	WinAmt  string `json:"win_amt"`
}

type GetRankRsp struct {
	Top3Ranks  []RankItem `json:"top3_ranks"`
	RankType   int32      `json:"rank_type"` // 0今日 1昨日
	Ranks      []RankItem `json:"ranks"`
	RankDate   string     `json:"rank_date"`
	PoolAmt    string     `json:"pool_amt"`
	SelfRankNo int32      `json:"self_rank_no"`
	SelfWinAmt string     `json:"self_rank_amt"`
	SelfPutAmt string     `json:"self_put_amt"`
}

type HeartBeat struct {
	UserId string `json:"user_id"`
}
