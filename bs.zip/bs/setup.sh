brew install protobuf
go env -w GOPROXY=https://goproxy.cn,direct
go install github.com/name5566/leaf
go install google.golang.org/grpc/cmd/protoc-gen-go-grpc@latest
go install google.golang.org/protobuf/cmd/protoc-gen-go@latest
go get -u github.com/golang/protobuf/proto
go get -u google.golang.org/grpc