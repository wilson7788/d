System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/spine-59f406dc.wasm")}}}));
